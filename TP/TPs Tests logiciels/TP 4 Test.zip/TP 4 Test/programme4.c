#include <stdlib.h>
#include <stdio.h>
#include <string.h>
typedef struct Pile
{
    int s;
    int max;
    float *tab;
} Pile;
Pile *creerPile(int max)
{
    Pile *p = malloc(sizeof(Pile));
    p->max = max;
    p->s = -1;
    p->tab = malloc(max * sizeof(float));
    return p;
}
int estVide(Pile *p)
{
    if (p == NULL)
        return -1;
    if (p->s == -1)
    {
        return 1;
    }
    return 0;
}
int estPleine(Pile *p)
{
    if (p == NULL)
        return -1;
    if (p->s == p->max - 1)
    {
        return 1;
    }
    return 0;
}
int depiler(Pile *p, float *e)
{
    if (p == NULL)
        return -1;
    if (estVide(p))
        return 0;
    *e = *(p->tab + p->s);
    p->s = p->s - 1;
    return 1;
}
int empiler(Pile *p, float e)
{
    if (p == NULL)
        return -1;
    if (estPleine(p))
        return 1;
    p->s = p->s + 1;
    p->tab[p->s] = e;
    return 0;
}

int main(int argc, char **args)
{
    Pile *p = NULL;
    float a1, a2, buffer;
    scanf("%f", &a1);
    scanf("%f", &a2);
    empiler(p, a1);
    depiler(p, &buffer);
    estPleine(p);
    estVide(p);
    p = creerPile(2);
    empiler(p, a1);
    estPleine(p);
    empiler(p, a2);
    estPleine(p);
    empiler(p, a1); // La pile est pleine
    depiler(p, &buffer);
    estVide(p);
    depiler(p, &buffer);
    estVide(p);
    depiler(p, &buffer); // la pile est vide
    return 0;
}