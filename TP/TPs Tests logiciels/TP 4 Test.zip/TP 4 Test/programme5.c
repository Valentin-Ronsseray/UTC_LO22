#include <stdio.h>
int pgcd()
{
    int x, y;
    scanf("%d", &x);
    scanf("%d", &y);
    while (x != y)
    {
        if (x > y)
            x = x - y;
        else
        {
            y = y - x;
        }
    }
    return x;
}
int main()
{
    pgcd();
    return 0;
}